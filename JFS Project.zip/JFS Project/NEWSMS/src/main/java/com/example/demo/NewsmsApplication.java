package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NewsmsApplication {

	public static void main(String[] args) {
		SpringApplication.run(NewsmsApplication.class, args);
	}

}
